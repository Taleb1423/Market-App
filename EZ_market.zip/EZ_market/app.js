
const express = require('express')
const mysql = require('mysql');
const app =express();

const LoremIpsum = require("lorem-ipsum").LoremIpsum;

const lorem = new LoremIpsum({
  sentencesPerParagraph: {
    max: 8,
    min: 4
  },
  wordsPerSentence: {
    max: 16,
    min: 4
  }
});
let aboutus = lorem.generateParagraphs(2);



app.use(express.urlencoded({extended: false}));
const db =mysql.createConnection({
    host     : 'localhost',
    user     : 'dbproject',
    password : 'Souheil131202&',
    database : 'db_pro'
})

let user;



db.connect((err) =>{
    if(err){
    throw err;
    }
    console.log('success');
});
app.set('view engine', 'ejs');

app.use(express.static('public'));

app.listen(5000);

console.log('listening');
let cart= [];
let products=[];

db.query("select * from online_info",(err,result,field)=>{
    
    products = result;
    
    
});

app.get('/', (req,res)=>{
    if (user==undefined){
        res.redirect('/login');
        res.end();
        
    }
    else{
    res.render('index',{products})
    res.end()
    }
});




app.get('/about', (req,res)=>{
    if (user==undefined){
        console.log(cart);
        res.redirect('/login');
        res.end();
    }
    
    res.render('info',{aboutus})

});



app.post("/add_to_cart",  (req,res)=>{
    cart.push(req.body.item);
    console.log(req.body.item.product_name);
    
    res.redirect('/');
       

});
app.get("/register", (req,res)=>{
    
 res.render('register')
});

app.get("/login", (req,res)=>{
 res.render('login');
});
app.post("/register", async (req,res)=>{
     
    
        
       db.query("INSERT INTO custumer(username,password,name,email,adress,phone,date_of_birth) values(?,?,?,?,?,?,?)",[req.body.username,req.body.password,req.body.fname+req.body.lname,req.body.email,req.body.adress,req.body.phone,req.body.DoB],
       (err,result,field)=>{
        if(err) {
            res.send('<div class="alert alert-primary" role="alert" align ="center">Registration failed, username/password is already tied to an account <br><a href="/register" class="alert-link">Back</a></div>');
            res.end();
        }
       else{
        res.redirect('/login');
        res.end();
       }
    
    });       
        

});

app.post('/login', (req,res) => {
db.query('select * from custumer where username =?',[req.body.username],(err,result,field) => {
if(result.length==0){
    res.send('<div class="alert alert-primary" role="alert" align ="center">login failed, username/password is incorret <br><a href="/login" class="alert-link">Back</a><br><a href="/register" class="alert-link">create account</a></div>')
    res.end();    
}
else if(result[0].password==req.body.password){
    user= req.body.username;
    res.redirect('/');  
    res.end();  
}
else{
    res.send('<div class="alert alert-primary" role="alert" align ="center">login failed, username/password is incorret <br><a href="/login" class="alert-link">Back</a><br><a href="/register" class="alert-link">create account</a></div>')}
    res.end();
});
});
app.get('/logout',(req,res)=>{
    user = undefined;
    res.redirect('/login');
    res.end();
})
app.get('/cart',(req,res)=>{
    if (user==undefined){
        res.redirect('/login');
        res.end();
        
    }
    res.render('cart',{cart,products});
    res.end();
})
app.post("/remove_from_cart",  (req,res)=>{
    cart.filter(function(ele){ 
        return ele != req.body.value; 
    
})
    res.redirect('/cart');  

});
app.post('/confirm', (req,res)=>{

db.query("insert into db_pro.order(time_and_date_placed,ord_user_id,order_price) values(CURRENT_TIMESTAMP,(select user_id from custumer where username=?),?)",[user,req.body.total ],(err,result)=>{
if(err){
    throw err;
    }
    else{
        for(let i=0; i<cart.length; i++){
            db.query("update unit set unit_order_id =(select max(order_id) from db_pro.order) where unit_product_name=?",[cart[i]],(err,result)=>{
                if(err){
                    throw err;
                
                }
                else{
                    res.send('<div class="alert alert-primary" role="alert" align ="center">Order processed <br><a href="/" class="alert-link">Back</a><br></div>');
                    res.end();
                }
            })    
        }

    }

})

});

